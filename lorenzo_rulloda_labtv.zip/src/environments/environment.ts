export const environment = {
    TMDB_API_URL: "https://api.themoviedb.org/3/",
    TMDB_API_KEY: "af8e8939ea011299cc2dfcd349a5bce1",
    LABTV_DB: "http://localhost:3000/"
};
